	$(document).ready(function(){
		var dataString;	var grn = '';	var mrk=''; var dod=''; 
		$('#loading').hide();
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------Party Search-----------------------------------------------
		$('#party_search').change( function(){
			$('.j').remove();
			$('#loading').show();
			party_search = $(this).val();
			dataString = 'gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_view='+is_view+'&is_fe='+is_fe;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------GRN Search-----------------------------------------------
		$('#grn').change( function(){
			$('.j').remove();
			$('#loading').show();
			grn = $(this).val();
			dataString = 'gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_view='+is_view+'&is_fe='+is_fe;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------Marka Search-----------------------------------------------
		$('#mrk').change( function(){
			mrk = $(this).val();
			$('.j').remove();
			$('#loading').show();
			dataString = 'gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_view='+is_view+'&is_fe='+is_fe;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------DOD Search-----------------------------------------------	

		$('#dod').change( function(){
			if($(this).val()!=''){
			dod = $(this).val().substring(6,8)+"-"+$(this).val().substring(3,5)+"-"+$(this).val().substring(0,2);}else{dod='';}
			//console.log(dod);
			
			$('.j').remove();
			$('#loading').show();
			dataString = 'gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_view='+is_view+'&is_fe='+is_fe;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------All Field Editable-----------------------------------------------
		$('#all_edit_btn').click(function(){
			$('.j').remove();
			$('#loading').show();
			dataString = 'gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_view='+is_view+'&is_fe='+is_fe;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_edit_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
	});