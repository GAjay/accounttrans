<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var pakka=0;var all=[];var allVals = []; </script>
	</head>
	<body class="content">
			<h2 class="heading">Unique Due</h2>
			<table id="c_d">
			<thead>
				<tr>
					<th><label>#</label></th>
					<th>Name</th>
					<th>Particular</th>
					<th>Address</th>
					<th>Due</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$count = 0;
				$sql="SELECT * FROM `party` WHERE `type`=1";
				$result=$db->query($sql);
				while($row=mysqli_fetch_array($result)){
					$sum=0;
					$p=$row['ID'];
					$sql_due = "SELECT * FROM `challan` WHERE `partyname`='$p' AND `paid`=0 AND `is_due`=0";
					$result_due=$db->query($sql_due);
					while($row_due=mysqli_fetch_array($result_due)){
						if($row_due['is_roundof']==1){
							$sum = $sum-$row_due['freight'];
						}
						else{
							$sum = $sum+$row_due['freight'];
						}
					}
					$count++;
					echo '<tr class="r">
						<td><label>'.$count.'</label></td>
						<td>'.$row['name'].'</td>
						<td>'.$row['particular'].'</td>
						<td>'.$row['address/mobile'].'</td>
						<td><span class="td_right">'.$sum.'</span></td>
					</tr>';
				}
			?>
			</tbody>
			</table>
		</div>
	</body>
</html>