<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$last_paid_date = $_SESSION['last_paid_date'];
	$member_id = $_SESSION['ID'];
	$readonly = 'readonly';
	if($_SERVER['REQUEST_METHOD']=="POST"){
		if(isset($_POST['fn'])){
			if(isset($_POST['count'])){
				foreach($_POST['count']as $i){
					$id=$_POST[$i.'_id'];
					$party_id=$_POST[$i.'_party_id'];
					$roundof_amount=$_POST[$i.'_roundof_amount'];
					$sql_undo="DELETE FROM `challan` WHERE `ID`='$id'";
					$sql_party="UPDATE `party` SET `round_of_amount`=`round_of_amount`-'$roundof_amount' WHERE `ID`='$party_id'";
					$reulst_undo=$db->query($sql_undo)or die();$reulst_party=$db->query($sql_party)or die();
				}
				echo '<h2>Selected Roundof undo paid successfully</h2>';
			}
			else{
				echo '<h2>Please select atleast one row</h2>';
			}
		}
		else{
			$id = $_POST['party'];
			$d = explode('-',$_POST['paid_at']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$paid_at = '20'.$n[2].'-'.$n[1].'-'.$n[0];
			$paid_at = Date($paid_at);
			$amount = $_POST['amount'];
			$particular = 'Round of Amount';
			$total_amount = $_POST['total_amount'];
			$created_at = date( 'Y-m-d');
			$updated_at = date( 'Y-m-d');
			$type=$_POST['type'];
			$sql1 = "INSERT INTO `challan`(`challanNo`, `particular`, `freight`, `paid_at`,`dateofdeparture`, `addedby`, `partyname`, `created_at`, `updated_at`, `is_roundof`, `is_pakka`) VALUES (0, '$particular', '$amount', '$paid_at', '$paid_at', '$member_id', '$id', '$created_at', '$updated_at', '1', '$type')";
			$sql2 = "UPDATE `party` SET `round_of_amount`='$total_amount' WHERE `ID`='$id'";
			$l_sql = "UPDATE `users` SET `last_paid_date`='$paid_at' WHERE `ID`='$member_id'"; 
			$l_result = $db->query($l_sql) or die("Sql Error :" . $db->error);
			$_SESSION['last_paid_date'] = $paid_at;
			$result1=$db->query($sql1) or die();$result2=$db->query($sql2) or die();
			echo '<h2>Selected Party\'s Roundof added successfully</h2>';
		}
	}
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var $round_of = []; var last_paid_date = new Date("<?php echo $last_paid_date;?>");</script>
		
	</head>
	<body class="content">
		<h2 class="heading">Roundof Payment</h2>
	<div id="paid">
			<form action="" method="POST" id="roundof_create" onkeypress="return event.keyCode != 13;">
			<label>Party Name: <select name="party" id="party" required>
				<option value="">--select--</option>
				<?php
					$sql="SELECT * FROM `party`";
					$result=$db->query($sql) or die();
					while($row=mysqli_fetch_array($result)){
						echo '<option value="'.$row['ID'].'&'.$row['type'].'">'.$row['name'].'</option><script>$round_of['.$row['ID'].']='.$row['round_of_amount'].';</script>';
					}
				?>
			</select></label>
			<label>Paid Date: <input type="text" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{2}" placeholder="dd-mm-yy" id="paid_at" name="paid_at" required></label>
			<label>In Account: <input type="text" id="in_acc" name="in_acc" value=0 readonly></label>
			<label>Paid Amount: <input type="text" id="amount" name="amount" value=0 required><input type="hidden" id="type" name="type"></label>
			<label>Total Amount: <input type="text" id="total_amount" name="total_amount" readonly></label>
			
			</form><h4 id="error" style="display:none;">You can't paid on that date</h4>
				<button class="button button2" id="paid_roundof_btn" form="roundof_create" type="submit">Update Roundof Payment</button>
			
			<?php
				$sql_paid="SELECT *, `challan`.`ID` AS `ID`, `challan`.`particular` AS `particular`, DATE_FORMAT(`paid_at`,'%d-%m-%Y') AS `paid_at` FROM `challan` INNER JOIN `party` ON `challan`.`paid`=0 AND `challan`.`partyname`=`party`.`ID` AND `challan`.`is_roundof`=1 AND `challan`.`is_due`=0 AND (NOT(`challan`.`particular` REGEXP 'Debit')) ORDER BY `dateofdeparture` DESC";
				$result_paid=$db->query($sql_paid) or die();
				$count=mysqli_num_rows($result_paid);
				if(($count>0)&&(preg_match('/8,9,1,2,3/',$perm)||preg_match('/2/',$perm))){
			?>
			<div class="button_right">
				<button class="button button5" id="delete_roundof">Delete Roundof</button>
			</div>
			<?php
				}
			?>
		</div>
		<div id="undo_paid">
			<button class="button button2" form="undo_roundof_form" id="undo_paid_btn">Undo paid Roundof</button>
			<button class="button button5" id="cancel_btn" type="submit">Cancel</button>
		<?php
			$sql_paid="SELECT *, `party`.`ID` AS `party_id`, `challan`.`ID` AS `ID`, `challan`.`particular` AS `particular`, DATE_FORMAT(`paid_at`,'%d-%m-%Y') AS `paid_at` FROM `challan` INNER JOIN `party` ON `challan`.`paid`=0 AND `challan`.`partyname`=`party`.`ID` AND `challan`.`is_roundof`=1 AND `challan`.`is_due`=0 AND (NOT(`challan`.`particular` REGEXP 'Debit')) ORDER BY `dateofdeparture` DESC";
			$result_paid=$db->query($sql_paid) or die();
			$count=mysqli_num_rows($result_paid);
			if($count>0){
		?>
			<form id="undo_roundof_form" action="" method="post" onkeypress="return event.keyCode != 13;">
			<input type="hidden" id="fn" name="fn">
			<table>
				<tr>
					<th><label><input type="checkbox" id="select_all"> #</label></th>
					<th>Party Name</th>
					<th>Paid date</th>
					<th>Particular</th>
					<th>Paid Amount</th>
				</tr>
				<tr>
				<?php
					$r=0;
					while($row_paid=mysqli_fetch_array($result_paid)){
						$r++;
						echo '<tr>
						<td><label><input type="checkbox" id="'.$r.'" name="count[]" value="'.$r.'" >
							<input type="hidden" name="'.$r.'_id" value="'.$row_paid['ID'].'"> '.$r.'</label></td>
						<td>'.$row_paid['name'].'<input type="hidden" name="'.$r.'_party_id" value="'.$row_paid['party_id'].'"></td>
						<td>'.$row_paid['paid_at'].'</td>
						<td>'.$row_paid['particular'].'</td>
						<td><span class="td_right">'.$row_paid['freight'].'<input type="hidden" name="'.$r.'_roundof_amount" value="'.$row_paid['freight'].'"></span></td>
						</tr>';
					}
				?>
				</tr>
			</table>
			</form>
			<script>
				$('#undo_paid_btn').click(function(){
					$('#fn').val('undo_paid');
				});
				$('#select_all').click(function(){
					$('input:checkbox').not(this).attr('checked', this.checked);
				});
				$("#cancel_btn").click(function(){
					window.location.href = 'round_of.php';
				});
			</script>
		<?php
			}
		?>
		</div>
	</body>
</html>

<script>
	$('#delete_roundof').click(function(){
		$('#paid').remove();
		$('#undo_paid').show();
	});
	$('#undo_paid').hide();
	$('#error').hide();
	$('#party').change(function(){
		str=$(this).val();
		n = str.search("&");
		party_id = str.substring(0,n);
		type=str.substring(n+1,str.length);
		$('#type').val(type);
		in_acc_amount = +$round_of[party_id];
		$('#in_acc').val(in_acc_amount);
		total = in_acc_amount+(+$('#amount').val());
		$('#total_amount').val(total);
	});
	$('#amount').change( function(){
		in_acc = +$('#in_acc').val();
		amount = +$('#amount').val();
		$('#total_amount').val(in_acc+amount);
	});
<?php
	if(!preg_match('/8,9,1,2,3/',$perm)){
?>
	$('#paid_at').change(function(){
		var paid_at;
		if($(this).val()!=''){
			paid_at = new Date("20"+$(this).val().substring(6,8)+"-"+$(this).val().substring(3,5)+"-"+$(this).val().substring(0,2));
		}
		else{
			paid_at = '';
		}
		if(+paid_at<+last_paid_date){
			$('#paid_roundof_btn').hide();$('#error').show();
		}
		else{
			$('#paid_roundof_btn').show();$('#error').hide();
		}
	});
<?php
	}
?>
</script>
