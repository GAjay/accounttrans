<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$ptrn_update = "/3/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	if(isset($_GET['msg'])){
		echo '<h3 style="color:Black;">'.$_GET['msg'].'</h3>';
	}
	$readonly = 'readonly';
	
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var allVals=[];</script>
		
	</head>
	<body class="content">
	<h1 class="heading">Unique Printed Challan</h1>
	<?php
		if(preg_match($ptrn_paid,$perm)){
	?>
	<div class="button_left">
		<label><input type="radio" name="company_id" value="2" checked> New India Transport Agency</label><br>
		<label><input type="radio" name="company_id" value="3"> New India Cargo Mover</label>
	</div>
	<div class="button_right">
		<button class="button button2" id="print_challan">Print</button>
	</div>
	<?php
		}
	?>
			<table id="main_table">
				<tr class="mh">
					<th><label>#</label></th>
					<th>RR No</th>
					<th>Challan No</th>
					<th>G.R.No</th>
					<th>Marka</th>
					<th>Nag</th>
					<th>particular</th>
					<th>weight</th>
					<th>freight</th>
					<th>partyname</th>
					<th>D.O.B.</th>
					<th>RR Date</th>
				<?php
					if(preg_match($ptrn_paid,$perm)){
						echo '<th></th>';
					}
				?>
				</tr>
				<tr class="fl">
					<th>
					<?php
						if(preg_match($ptrn_paid,$perm)){
							echo '<input type="checkbox" id="all_select" >';
						}
					?>
					</th>
					<th></th>
					<th></th>
					<th><input class="search" type="number" id="grn" list="grn_li"></th>
					<?php
						$sql = ("SELECT `G.R.No` FROM `challan` WHERE `is_print`=1 group by `G.R.No`");
						$result = $db->query($sql) or die("Sql Error :" . $db->error);
						echo '<datalist id="grn_li"><select>';
						while($row = mysqli_fetch_array($result)){
							echo '<option>'.$row['G.R.No'].'</option>';
						}
						echo '</select></datalist>';
					?>
					<th><input class="search" type="text" id="mrk" list="mrk_li"></th>
					<datalist id="mrk_li"><select id="mrk_li_option">
						<?php
							$sql = ("SELECT `marka` FROM `challan` WHERE `is_print`=1 group by marka");
							$result = $db->query($sql) or die("Sql Error :" . $db->error);
							while($row = mysqli_fetch_array($result)){
								echo '<option>'.$row['marka'].'</option>';
							}
						?>
					</select></datalist>
					<th></th>
					<th></th>
					<th></th>
					<th></th>
					<th><select class="search" id="party_search">
						<option value="">--select--</option>
								<?php	$sql1="SELECT * FROM `party` WHERE `type`=1";
									$result1 = $db->query($sql1) or die("Sql Error :" . $db->error);
									while($row1 = mysqli_fetch_array($result1)){
										echo '<option value="'.$row1['ID'].'">'.$row1['name'].'</option>';
									}
								?>
								</select></th>
					<th><input type="text" class="search" id="dod" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{2}" placeholder="dd-mm-yy"></th>
					<th></th>
				<?php
					if(preg_match($ptrn_paid,$perm)){
						echo '<th></th>';
					}
				?>
				</tr>
				<?php
				$sql="SELECT *,`challan`.`ID`AS`ID`, `pakkachallan`.`ID`AS`pakka_id`, 
				DATE_FORMAT(`challan`.`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, 
				DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print` 
				FROM `challan` INNER JOIN `pakkachallan` 
				ON
				`challan`.`is_pakka`=1 AND `challan`.`is_print`=1 AND `challan`.`is_roundof`=0 AND `challan`.`paid`=0 AND `challan`.`ID`=`pakkachallan`.`challan_id` AND `challan`.`is_due`=0 ORDER BY `pakkachallan`.`date_of_print` DESC";
				$result=$db->query($sql) or die();$count=0;
				while($row = mysqli_fetch_array($result)){
				echo '<tr class="j">';
					$count++;
					echo '<td><label>';
					if(preg_match($ptrn_update,$perm)){
						echo '<input type="checkbox" id="'.$count.'" name="count[]" value="'.$row['ID'].'" >';
					}
					echo $count.'</label></td>
					<td><span class="td_right">'.$row['pakka_id'].'</span></td>
					<td><span class="td_right">'.$row['challanNo'].'</span></td>
					<td><span class="td_right">'.$row['G.R.No'].'</span></td>
					<td>'.$row['marka'].'</td>
					<td><span class="td_right">'.$row['nag'].'</span></td>
					<td>'.$row['particular'].'</td>
					<td><span class="td_right">'.$row['weight'].'</span></td>
					<td><span class="td_right">'.$row['freight'].'</span></td>';
					$p_id = $row['partyname'];
					echo '<td>';
							$sql2="SELECT * FROM `party` WHERE `ID`='$p_id'";
							$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
							$row2 = mysqli_fetch_array($result2);
								if($row2['ID']==$p_id){
									echo $row2['name'];
								}
					echo'</td>
					<td>'.$row['dateofdeparture'].'</td>
					<td>'.$row['date_of_print'].'</td>';
					if(preg_match($ptrn_paid,$perm)){
						echo '<td><a href="pakka_view.php?challan_id='.$row['ID'].'" >View</a></td>';
					}
				
					echo '</tr>';
				}
			?>
			</table>
			<img align="center" src="../img/loading.gif" id="loading" height="90px">
		</form>
		</div>
		<div id='table'></div>
		
		</body>
</html>



<script>
	$(document).ready(function(){
		var dataString;	var grn = ''; var party_search=''; var pakka=1; var mrk=''; var dod='';var is_print=1; 
		$('#loading').hide();
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------Party Search-----------------------------------------------
		$('#party_search').change( function(){
			party_search = $(this).val();
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------GRN Search-----------------------------------------------
		$('#grn').change( function(){
			grn = $(this).val();
			
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------Marka Search-----------------------------------------------
		$('#mrk').change(function(){
			mrk = $(this).val();
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------DOD Search-----------------------------------------------	
		$('#dod').change(function(){
			if($(this).val()!=''){
				dod = $(this).val().substring(6,8)+"-"+$(this).val().substring(3,5)+"-"+$(this).val().substring(0,2);
			}
			else{
				dod='';
			}
		});
//----------------------------------------------------------------------------------------------------------
//--------------------------------------------search-----------------------------------------------
		$('.search').change(function(){
			$('.j').remove();
			$('#loading').show();
			dataString = 'printed=printed&gr_no='+grn+'&mrk='+mrk+'&dod='+dod+'&party='+party_search+'&pakka='+pakka+'&is_print='+is_print;
			//console.log(dataString);
			$.ajax
			({
				type: "POST",
				url: "get/get_pakka_challan_table.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
				{
					$('#loading').hide();
					$('#main_table').append(data);
				}
			});
		});
		$("#all_select").click(function(){
			$('input:checkbox').not(this).attr('checked', this.checked);
			allVals=[];
				$('.j :checked').each(function() {
					allVals.push($(this).val());
				});
		});
		$('.j input').click(function() { 
			allVals=[];
			$('.j :checked').each(function() {
				allVals.push($(this).val());
			});//console.log(allVals);
		});
		$('#print_challan').click(function(){
			company_id=$('input[name=company_id]:checked').val();
			$('#table').hide();
			dataString = 'company_id='+company_id+'&check='+allVals;
			//console.log(dataString);
			$.ajax({
				type: "POST",
				url: "push/print_printed.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
					{
						//console.log(data);
						$('#table').html(data);
						//$('#table').show();
					}
			});
		});
	});
</script>
