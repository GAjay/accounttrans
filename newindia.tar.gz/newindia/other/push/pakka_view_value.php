<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$show=0;
	$challan_id=$_GET['challan_id'];
	$member_id = $_SESSION['ID'];		
		if($_SERVER['REQUEST_METHOD']=="POST"){
			$sender=$_POST['sender'];
			$receiver=$_POST['receiver'];
			$freight=$_POST['freight'];
			$commission=$_POST['commission'];
			$labour=$_POST['labour'];
			$s_charge=$_POST['s_charge'];
			$g_tax=$_POST['g_tax'];
			$goushala=$_POST['goushala'];
			$total=$_POST['total'];
			$updated_at=date('y-m-d');
			$sql_update = "UPDATE `pakkachallan` SET `sender`='$sender', `receiver`='$receiver', `freight`='$freight', `commission`='$commission', `labour`='$labour', `serviceTax`='$s_charge', `gTax`='$g_tax', `goushala`='$goushala', `total`='$total', `updated_at`='$updated_at' WHERE `challan_id` = '$challan_id'";
			$sql_challan_update="UPDATE `challan` SET `freight`='$freight' WHERE `ID`='$challan_id'";
			$result_update=$db->query($sql_update) or die("Sql_update Error:".$db->error);
			$result_update_challan=$db->query($sql_challan_update) or die("Sql_update Error:".$db->error);
			if($_POST['btn']=='conform'){
				$readonly='readonly';
				$show=1;
			}
			if($result_update&&$result_update_challan){
				header('Location: ../pakka_view.php?challan_id='.$challan_id.'&show='.$show);
			}
		}
?>