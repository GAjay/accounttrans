<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$sql;$date=Date('20y/m/d');
	if($_POST['id']!=''){
		$challan_id=$_POST['id'];
//-------------------------------update query to set is_print and date in pakkachallan and challan table------------------------
		$update_challan="UPDATE `pakkachallan` SET `is_print`=1, `date_of_print`='$date', `updated_at`='$date' WHERE `challan_id`='$challan_id' ";
		$update_pakkachallan="UPDATE `challan` SET `is_print`=1, `updated_at`='$date' WHERE `ID`='$challan_id'";
	
	$result=$db->query($update_challan)or die();
	$result_pakkachallan=$db->query($update_pakkachallan)or die();		//after print setting please uncomment this statement 


//------------------------------------------------------------------------------------------------------------------------------

//------------------------------------------Select Query From pakkachallan Table------------------------------------------------
		$sql="SELECT *,`pakkachallan`.`ID` AS `ID`, `challan`.`freight` AS `freight` FROM `pakkachallan` INNER JOIN `challan` ON `pakkachallan`.`challan_id`= '$challan_id' AND `pakkachallan`.`challan_id`=`challan`.`ID`";
		$result=$db->query($sql) or die('sql Error: '.$db->error);
		$row=mysqli_fetch_array($result);
//------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------SELECT query From officeData table---------------------------------------------------
		$sql_office="SELECT * FROM `officeData` WHERE `ID`=1";
		$result_office=$db->query($sql_office) or die('sql Error: '.$db->error);
		$row_o=mysqli_fetch_array($result_office);
//------------------------------------------------------------------------------------------------------------------------------
?>
		<div id="report">
			<div  id="container">
					<div id="left"><?php echo $row_o['mobile1'];?><br>
												<?php echo $row_o['mobile2'];?></div>
					<div  id="center"><small>|| Jai Baba Ramdev Ji ||</small></div>
					<div  id="right"><?php echo $row_o['mobile3'];?></div>
			</div>
			<div class="name">
				<h2><?php echo $row_o['companyName'];?></h2>
			</div>
			<div class="address">
				<?php echo $row_o['address'];?>
			</div>
			<div>
				<div class="common">
					<label style="float:left;">No.: <?php echo $row['ID'];?></label>
					<label style="float:right;">Date: <?php echo $date;?></label>
				</div>
				<div class="common">
				<label style="float:left;">M/S: <span class="border-bottom"><?php echo $row['marka'];?></span></label>
				<label style="float:right">Nag:<?= $row['nag']?> Weight:<?= $row['weight']?></label>
				</div>
				<div class="common">
				<label  style="float:left;">From: <?php echo $row['from'];?></label>
				<label style="float:right;">G.R.No.: <?php echo $row['G.R.No'];?></label>
				</div>
			<table style="margin-top:2em;" >
  <tr>
    <th></th>
    <th>Amount</th>
    <th></th>
  </tr>
  <tr>
    <td>FREIGHT</td>
    <td><?php echo $row['freight'];?></td>
    <td>00</td>
  </tr>
  <tr>
    <td>COMMISSION</td>
    <td><?php echo $row['commission'];?></td>
    <td>00</td>
  </tr>
  <tr>
    <td>LABOUR</td>
    <td><?php echo $row['labour'];?></td>
    <td>00</td>
  </tr>
  <tr>
    <td>G.TAX</td>
    <td><?php echo $row['gTax'];?></td>
    <td>00</td>
  </tr>
  <tr>
    <td>Cow House</td>
    <td><?php echo $row['goushala'];?></td>
    <td>00</td>
  </tr>
  <tr>
    <td>Service Tax</td>
    <td><?php echo $row['serviceTax'];?></td>
    <td>00</td>
  </tr>
  	<tr>
    <th>Total</td>
    <th><?php echo $row['total'];?></td>
    <th>00</td>
  </tr>
</table>
					
				
			<div class="common">
				<label style="float:left;">Customer's Sig.</label>
				<label style="float:right;">Signature</label>
			</div>
		</div>
<?php	
	}
?>
<script>
	$(document).ready(function(){
			var divContents = $("#table").html();
			var printWindow = window.open('', '', 'height=600px,width=600px');
			printWindow.document.write('<html><head>');
			printWindow.document.write('<style>  @page {size:4.1in 5.8in;size: portrait;} @media print{ table {margin-top:20px;font-size:11px;cell-padding:4px;width:100%;border-spacing: 0px;border-collapse: separate;}table,thead{border-top:1px dashed black;border-bottom:1px dashed black;border-collapse: collapse;} th{border-bottom: 1px dashed black;   font-size:11px; border-collapse: collapse;}th, td {    padding: 0.8em;    text-align: left;}table tr:nth-child(even) {    background-color: #eee;}table tr:nth-child(odd) {    background-color:#fff;}table th {    background-color: White;    color: Black; font-width:bold;}.common{clear:both;}.border-bottom{border-bottom:1px dashed black;}.common label{margin-top:10px;}.data{margin-top:3em;}body{font-family: Arial;margin:0 auto;font-size:11px;}#container {width:100%;text-align:center;}#left {float:left;width:100px;}#center{display: inline-block;margin:0 auto;width:105px;}#right {float:right;width:100px;}.name{border-top:1px dashed black;border-bottom:1px dashed black;clear:both;text-align:center;margin-top:2em;}.name h2{font-size:14px;}.address{margin-top:10px;text-align:center;font-size:10px;}}</style>');
			printWindow.document.write('</head><body>');
			printWindow.document.write(divContents);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		});
</script>
