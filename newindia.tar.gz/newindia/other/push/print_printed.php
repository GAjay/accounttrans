<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$selected = $_POST['check'];
	$sum_weight=0;
	$sum_freight=0;
	$company_id=$_POST['company_id'];
//-----------------------------------------SELECT query From officeData table---------------------------------------------------
		$sql_office="SELECT * FROM `officeData` WHERE `ID`='$company_id'";
		$result_office=$db->query($sql_office) or die('sql Error: '.$db->error);
		$row_o=mysqli_fetch_array($result_office);
		$selected=explode(',',$_POST['check']);
		$k=0;$pakka_ids=null;
		foreach($selected as $select){
			$result_id=$db->query("SELECT `ID` FROM `pakkachallan` WHERE `challan_id`='$select'")or die('1'.$db->error);
			$row_id=mysqli_fetch_array($result_id);
			if($k==0){
				$pakka_ids=$row_id['ID'];
			}
			else{
				$pakka_ids=$pakka_ids.','.$row_id['ID'];
			}
			$k++;
		}
//------------------------------------------------------------------------------------------------------------------------------
?>
<div id="report">
<?php
	if(sizeof($selected)>0&&$selected[0]!=''){
		$result_pakka=$db->query("INSERT INTO `printed_pakkachallan`(`pakka_ids`) SELECT '$pakka_ids' FROM DUAL WHERE NOT EXISTS( SELECT * FROM `printed_pakkachallan` WHERE `pakka_ids` = '$pakka_ids')")or die('2.'.$db->error);
		$result_pakka=$db->query("SELECT `ID` FROM `printed_pakkachallan` WHERE `pakka_ids` = '$pakka_ids'")or die('3'.$db->error);
		$row_pakka=mysqli_fetch_array($result_pakka);
?>
	<div>
		<div align="center">
			<p style="text-align:center;">||Jai Baba Ramdev Ji||</p>
			<div style="float:right;">
				<span><?php echo $row_o['mobile1'];?></span><br>
				<span><?php echo $row_o['mobile2']?></span><br>
			</div>
		</div>
		<div style="text-align:center;clear:both;">
		<h2 ><?php echo $row_o['companyName']?></h2>
		<pre style="font-family:times new roman;"><?php echo $row_o['address']?></pre>
		</div>
		<hr>
		<span style="float:left;">Invoice No. <?php echo $row_pakka['ID'];?></span>
		<span style="float:right;">Date <?php echo date('d-m-y');?></span><br>
		
	</div><br>
	<table style="margin-top:20px;">
		<tr>
			<th>#</th>
			<th>RR Date</th>
			<th>RR No</th>
			<th>G.R.No</th>
			<th>Nag</th>
			<th>Weight</th>
			<th>Freight</th>
		</tr>
		<?php
			$count=0;
			foreach($selected as $s){
				$count++;
				$sql="SELECT `challan`.`partyname`AS`partyname`,`pakkachallan`.`G.R.No` AS `G.R.No`, `challan`.`nag`AS`nag`, `challan`.`weight`AS`weight`, `pakkachallan`.`freight`, DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print`, `pakkachallan`.`ID`AS`ID`  FROM `challan` INNER JOIN `pakkachallan` ON `pakkachallan`.`challan_id`=`challan`.`ID` AND `pakkachallan`.`challan_id`='$s'";
				$result=$db->query($sql)or die();
				$row=mysqli_fetch_array($result);
				echo'<tr>
					<td>'.$count.'</td>
					<td>'.$row['date_of_print'].'</td>
					<td><span class="td_right">'.$row['ID'].'</span></td>
					<td><span class="td_right">'.$row['G.R.No'].'</span></td>
					<td><span class="td_right">'.$row['nag'].'</span></td>
					<td><span class="td_right">'.$row['weight'].'</span></td>
					<td><span class="td_right">'.$row['freight'].'</span></td>
				<tr>';
				$sum_weight=$sum_weight+$row['weight'];
				$sum_freight=$sum_freight+$row['freight'];
				if($count==1){
					$p_id=$row['partyname'];
					$result_p=$db->query("SELECT `name` FROM `party` WHERE `ID`='$p_id'")or die();
					$row_p= mysqli_fetch_array($result_p);
					echo '<p style="text-align:center;">To: '.$row_p['name'].'</p>';
				}
			}
		?>
		<tr>
			<td></td>
			<td colspan="4" align="center">Total</td>
			<td><span class="td_right"><?php echo $sum_weight;?></span></td>
			<td><span class="td_right"><?php echo $sum_freight;?></span></td>
		</tr>
	</table>
	<span style="position:absolute;bottom:30px;right:10px;">(Authorize Signature)</span>
</div>
	<?php }?>
<script>
	$(document).ready(function(){
			var divContents = $("#report").html();
			var printWindow = window.open('', '', 'height=600px,width=600px');
			printWindow.document.write('<html><head>');
			printWindow.document.write('<style>@page{size:8.27in 11.69in ;}table { width:100%; font-family: \'Lato Black\', sans-serif;}'+
'th{ text-transform:capitalize;}'+
'table, th, td { font-family: \'Lato Black\', sans-serif;    border: 1px solid #2C3E50;    border-collapse: collapse; }'+
'th, td {    padding: 5px;    text-align: left;}'+
'th {    font-weight:bold;}.td_right{	float: right;}</style>');
			printWindow.document.write('</head><body>');
			printWindow.document.write(divContents);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		});
</script>
		