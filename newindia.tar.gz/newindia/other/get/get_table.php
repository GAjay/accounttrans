<?php
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$ptrn_update = "/3/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	$ptrn_f_edit="/4/";
	include('../../configure/config.php');
	$party=null;$gr_no=null;$mrk=null;$frght=null;$dod=null;
	$is_fe=$_POST['is_fe'];
		$is_pakka=$_POST['pakka'];
		$party = $_POST['party'];
		$party = '^'.$party.'$';
	if(isset($_POST['gr_no'])){
		$gr_no= mysqli_real_escape_string($db,$_POST['gr_no']);
		$gr_no = '^'.$gr_no.'[0-9]*';
	}
	if(isset($_POST['mrk'])){
		$mrk = mysqli_real_escape_string($db,$_POST['mrk']);
		$mrk = $mrk.'[a-zA-Z0-9]*';
	}
	if(isset($_POST['pakka'])){
		$pakka = $_POST['pakka'];
	}
	$is_view=$_POST['is_view'];
	if($_POST['dod']!=''){
		$d = explode('-',$_POST['dod']);
		$i=0;$n;
		foreach($d as $p){
			$n[$i]=$p;
			$i++;
		}
		$dod  = '20'.$n[0].'-'.$n[1].'-'.$n[2];
		$dod  = Date($dod );
		$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`partyname` REGEXP '$party') AND (`marka` REGEXP '$mrk') AND `dateofdeparture`='$dod' AND `paid`=0 AND `is_pakka`='$pakka' AND `is_roundof`=0 AND `is_due`=0 AND `is_print`=0");
	}
	else{
		$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`partyname` REGEXP '$party') AND (`marka` REGEXP '$mrk') AND `paid`=0 AND `is_pakka`='$pakka'  AND `is_roundof`=0 AND `is_due`=0 AND `is_print`=0");
	}

		$result = $db->query($sql) or die();
		$count = 0;
		$readonly = 'readonly';
		while($row = mysqli_fetch_array($result)){
			echo '<tr class="j">';
				$count++;
				echo '<td><label>';
				if(preg_match($ptrn_update,$perm)||preg_match($ptrn_f_edit,$perm)){
					echo '<input type="checkbox" id="'.$count.'" name="count[]" value="'.$count.'" >
					<input type="hidden" name="'.$count.'_id_value" value="'.$row['ID'].'">';
				}
				echo $count.'</label></td>
				<td><span class="td_right">'.$row['challanNo'].'</span></td>
				<td><span class="td_right">'.$row['G.R.No'].'</span></td>
				<td>'.$row['marka'].'</td>
				<td><span class="td_right">'.$row['nag'].'</span></td>		
				<td>'.$row['particular'].'</td>
				<td><span class="td_right">'.$row['weight'].'</span></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_freight" id="'.$count.'_freight" value="'.$row['freight'].'" '.$readonly.'></td>';
				$p_id = $row['partyname'];
				echo '<td>';
				$sql2="SELECT * FROM `party`";
				$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
				if($is_fe==1){
					while($row2 = mysqli_fetch_array($result2)){
					if($row2['ID']==$p_id){
						echo $row2['name'];
					}}
				}
				else{
					echo '<select name="'.$count.'_partyname">';
						while($row2 = mysqli_fetch_array($result2)){
							if($row2['ID']==$p_id){
								echo '<option value="'.$row2['ID'].'" selected>'.$row2['name'].'</option>';
							}
							else{
								echo '<option value="'.$row2['ID'].'">'.$row2['name'].'</option>';
							}
						}
					
					echo '</select>';
				}
				echo '</td>
				<td>'.$row['dateofdeparture'].'</td>
				<td>'.$row['truckno'].'</td>';
				if($is_pakka==1&&$is_view==1&&preg_match($ptrn_paid,$perm)){
					echo '<td><a href="pakka_view.php?challan_id='.$row['ID'].'" >View</a></td>';
				}				
			echo '</tr>';
		}
?>
<script>
<?php
		$f=$count;
		while($f>0){
			echo"$('#".$f."_freight').change(function(){
				$(this).val(evil($(this).val()));
			});";
			$f--;
		}
	?>
	<?php
		$j=$count;
		if(preg_match($ptrn_update,$perm)||preg_match($ptrn_f_edit,$perm)){
		while($count>0){
			echo '$("#'.$count.'").click(function(){
				if($(this).is(":checked")){
					$(".'.$count.'_read").attr("readonly",false);
				}
				else{
					$(".'.$count.'_read").attr("readonly",true);
				}
			});';
			$count--;
		}
		}
	?>
	$("#all_select").click(function(){
	$('input:checkbox').not(this).attr('checked', this.checked);
		<?php 
			if(preg_match($ptrn_update,$perm)||preg_match($ptrn_f_edit,$perm)){
			while($j>0){echo '
				if($(this).is(":checked")){
					$(".'.$j.'_read").attr("readonly",false);
				}
				else{
					$(".'.$j.'_read").attr("readonly",true);
				}';
				$j--;
			}
			}
		?>
	});
</script>