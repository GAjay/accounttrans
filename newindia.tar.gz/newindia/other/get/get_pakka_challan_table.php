<?php
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$ptrn_update = "/1,2/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	$ptrn_f_edit="/4/";
	include('../../configure/config.php');
	$party=null;$gr_no=null;$mrk=null;$frght=null;$dod=null;
		$is_pakka=$_POST['pakka'];
		//$party = '^'.$party.'$';
	if(isset($_POST['gr_no'])){
		$gr_no= mysqli_real_escape_string($db,$_POST['gr_no']);
		$gr_no = '^'.$gr_no.'[0-9]*';
	}
	if(isset($_POST['mrk'])){
		$mrk = mysqli_real_escape_string($db,$_POST['mrk']);
		$mrk = $mrk.'[a-zA-Z0-9]*';
	}
	if(isset($_POST['pakka'])){
		$pakka = $_POST['pakka'];
	}
	$is_print=$_POST['is_print'];
//------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------Pakka challan-------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------
if(!isset($_POST['printed'])){
	if($_POST['party']!=''){
		$party = '^'.$_POST['party'].'$';
		if($_POST['dod']!=''){
			$d = explode('-',$_POST['dod']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$dod  = '20'.$n[0].'-'.$n[1].'-'.$n[2];
			$dod  = Date($dod );
			$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`partyname` REGEXP '$party') AND (`marka` REGEXP '$mrk') AND `dateofdeparture`='$dod' AND `is_pakka`=1 AND `is_print`=0 AND `is_roundof`=0 AND `paid`=0 AND `is_due`=0");
		}
		else{
			$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`partyname` REGEXP '$party') AND (`marka` REGEXP '$mrk') AND `is_pakka`=1 AND `is_print`=0 AND `is_roundof`=0 AND `paid`=0 AND `is_due`=0");
		}
	}
	else{
		if($_POST['dod']!=''){
			$d = explode('-',$_POST['dod']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$dod  = '20'.$n[0].'-'.$n[1].'-'.$n[2];
			$dod  = Date($dod );
			$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`marka` REGEXP '$mrk') AND `dateofdeparture`='$dod' AND `is_pakka`=1 AND `is_print`=0 AND `is_roundof`=0 AND `paid`=0 AND `is_due`=0");
		}
		else{
			$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE (`G.R.No` REGEXP '$gr_no') AND (`marka` REGEXP '$mrk') AND `is_pakka`=1 AND `is_print`=0 AND `is_roundof`=0 AND `paid`=0 AND `is_due`=0");
		}
	}
		$result = $db->query($sql) or die();
		$count = 0;
		$readonly = 'readonly';
		
		
		if(isset($_POST['edit'])){
		while($row = mysqli_fetch_array($result)){
			echo '<tr class="j">';
				$count++;
				echo '<td><label>';
				if(preg_match($ptrn_update,$perm)){
					echo '<input type="checkbox" id="'.$count.'" name="count[]" value="'.$count.'" >
					<input type="hidden" name="'.$count.'_id_value" value="'.$row['ID'].'">';
				}
				echo $count.'</label></td>
				<td>'.$row['challanNo'].'</td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_g_r_n" value="'.$row['G.R.No'].'" '.$readonly.'></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_marka" value="'.$row['marka'].'" '.$readonly.'></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_nag" value="'.$row['nag'].'" '.$readonly.'></td>		
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_particular" value="'.$row['particular'].'" '.$readonly.'></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_weight" value="'.$row['weight'].'" '.$readonly.'></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_freight" id="'.$count.'_freight" value="'.$row['freight'].'" '.$readonly.'></td>';
				$p_id = $row['partyname'];
				echo '<td>
					<select name="'.$count.'_partyname">';
						$sql2="SELECT * FROM `party`";
						$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
						while($row2 = mysqli_fetch_array($result2)){
							if($row2['ID']==$p_id){
								echo '<option value="'.$row2['ID'].'" selected>'.$row2['name'].'</option>';
							}
							else{
								echo '<option value="'.$row2['ID'].'">'.$row2['name'].'</option>';
							}
						}
					
					echo '</select>
				</td>
				<td><!input type="text" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-20[0-9]{2}" name="'.$count.'_dateofdeparture" value=">'.$row['dateofdeparture'].'<!" '.$readonly.'></td>
				<td><input class="'.$count.'_read" type="text" name="'.$count.'_truckno" value="'.$row['truckno'].'" '.$readonly.'></td>';
				if($is_pakka==1&&preg_match($ptrn_paid,$perm)){
					echo '<td></td>';
				}
			echo '</tr>';
		}
		
		}
		else{		
		while($row = mysqli_fetch_array($result)){
		echo '<tr class="j">';
			$count++;
			echo '<td><label>';
			if(preg_match($ptrn_update,$perm)){
				if($is_print==1){
					echo '<input type="checkbox" class="ch" id="'.$count.'" name="count[]" value="'.$row['ID'].'" >';
				}
				else{
					echo'<input type="checkbox" id="'.$count.'" name="count[]" value="'.$count.'" >
						<input type="hidden" name="'.$count.'_id_value" value="'.$row['ID'].'">';
				}
			}
			echo $count.'</label></td>
			<td><span class="td_right">'.$row['challanNo'].'</span></td>
			<td><span class="td_right">'.$row['G.R.No'].'</span></td>
			<td>'.$row['marka'].'</td>
			<td><span class="td_right">'.$row['nag'].'</span></td>
			<td>'.$row['particular'].'</td>
			<td><span class="td_right">'.$row['weight'].'</span></td>';
			
			if($is_print==1){
				echo'<td><span class="td_right">'.$row['freight'].'</span></td>';
			$p_id = $row['partyname'];
			echo '<td>';
					$sql2="SELECT * FROM `party`WHERE `ID`='$p_id'";
					$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
					$row2 = mysqli_fetch_array($result2);
						if($row2['ID']==$p_id){
							echo $row2['name'];
						}
				echo '</td>';
			}
			else{
			echo'<td><input class="'.$count.'_read" type="text" name="'.$count.'_freight" id="'.$count.'_freight" value="'.$row['freight'].'" '.$readonly.'></td>';
			$p_id = $row['partyname'];
			echo '<td>
				<select name="'.$count.'_partyname">';
					$sql2="SELECT * FROM `party`";
					$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
					while($row2 = mysqli_fetch_array($result2)){
						if($row2['ID']==$p_id){
							echo '<option value="'.$row2['ID'].'" selected>'.$row2['name'].'</option>';
						}
						else{
							echo '<option value="'.$row2['ID'].'">'.$row2['name'].'</option>';
						}
					}
				
				echo '</select>
			</td>';
			}
			echo'<td>'.$row['dateofdeparture'].'</td>
			<td>'.$row['truckno'].'</td>';
			if(preg_match($ptrn_paid,$perm)){
				echo '<td><a href="pakka_view.php?challan_id='.$row['ID'].'" >View</a></td>';
			}
		
			echo '</tr>';
		}
		}
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------END PAKKA CHALLAN------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------Printed Pakka challan--------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
else{
	$sql_printed=0;
	if($_POST['party']!=''){
		$party = '^'.$_POST['party'].'$';
		if($_POST['dod']!=''){
			$d = explode('-',$_POST['dod']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$dod  = '20'.$n[0].'-'.$n[1].'-'.$n[2];
			$dod  = Date($dod );
			$sql_printed = ("SELECT *,`challan`.`ID`AS`ID`, `pakkachallan`.`ID`AS`pakka_id`, DATE_FORMAT(`challan`.`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print` 
			FROM `challan` INNER JOIN `pakkachallan` 
			ON
			`challan`.`is_pakka`=1 AND `challan`.`is_print`=1 AND `challan`.`is_roundof`=0 AND `challan`.`paid`=0 AND `challan`.`ID`=`pakkachallan`.`challan_id` 
			AND (`challan`.`G.R.No` REGEXP '$gr_no') AND (`challan`.`partyname` REGEXP '$party') AND (`challan`.`marka` REGEXP '$mrk')
			AND `dateofdeparture`='$dod' AND `is_due`=0
			ORDER BY `pakkachallan`.`date_of_print` DESC");
		}
		else{
			$sql_printed = ("SELECT *,`challan`.`ID`AS`ID`, `pakkachallan`.`ID`AS`pakka_id`, DATE_FORMAT(`challan`.`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print` 
			FROM `challan` INNER JOIN `pakkachallan` 
			ON
			`challan`.`is_pakka`=1 AND `challan`.`is_print`=1 AND `challan`.`is_roundof`=0 AND `challan`.`paid`=0 AND `challan`.`ID`=`pakkachallan`.`challan_id` 
			AND (`challan`.`G.R.No` REGEXP '$gr_no') AND (`challan`.`partyname` REGEXP '$party') AND (`challan`.`marka` REGEXP '$mrk') AND `is_due`=0
			ORDER BY `pakkachallan`.`date_of_print` DESC");
		}
	}
	else{
		if($_POST['dod']!=''){
			$d = explode('-',$_POST['dod']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$dod  = '20'.$n[0].'-'.$n[1].'-'.$n[2];
			$dod  = Date($dod );
			$sql_printed = ("SELECT *,`challan`.`ID`AS`ID`, `pakkachallan`.`ID`AS`pakka_id`, DATE_FORMAT(`challan`.`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print` 
			FROM `challan` INNER JOIN `pakkachallan` 
			ON
			`challan`.`is_pakka`=1 AND `challan`.`is_print`=1 AND `challan`.`is_roundof`=0 AND `challan`.`paid`=0 AND `challan`.`ID`=`pakkachallan`.`challan_id` 
			AND (`challan`.`G.R.No` REGEXP '$gr_no') AND (`challan`.`marka` REGEXP '$mrk')
			AND `dateofdeparture`='$dod' AND `is_due`=0
			ORDER BY `pakkachallan`.`date_of_print` DESC");
		}
		else{
			$sql_printed = ("SELECT *,`challan`.`ID`AS`ID`, `pakkachallan`.`ID`AS`pakka_id`, DATE_FORMAT(`challan`.`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`pakkachallan`.`date_of_print`,'%d-%m-%Y') as `date_of_print` 
			FROM `challan` INNER JOIN `pakkachallan` 
			ON
			`challan`.`is_pakka`=1 AND `challan`.`is_print`=1 AND `challan`.`is_roundof`=0 AND `challan`.`paid`=0 AND `challan`.`ID`=`pakkachallan`.`challan_id` 
			AND (`challan`.`G.R.No` REGEXP '$gr_no') AND (`challan`.`marka` REGEXP '$mrk') AND `is_due`=0
			ORDER BY `pakkachallan`.`date_of_print` DESC");
		}
	}
		$result_printed=$db->query($sql_printed) or die();
			$count=0;
				while($row_print = mysqli_fetch_array($result_printed)){
				echo '<tr class="j">';
					$count++;
					echo '<td><label>';
					if(preg_match($ptrn_update,$perm)){
						echo '<input type="checkbox" id="'.$count.'" name="count[]" value="'.$row_print['ID'].'" >';
					}
					echo $count.'</label></td>
					<td><span class="td_right">'.$row_print['pakka_id'].'</span></td>
					<td><span class="td_right">'.$row_print['challanNo'].'</span></td>
					<td><span class="td_right">'.$row_print['G.R.No'].'</span></td>
					<td>'.$row_print['marka'].'</td>
					<td><span class="td_right">'.$row_print['nag'].'</span></td>
					<td>'.$row_print['particular'].'</td>
					<td><span class="td_right">'.$row_print['weight'].'</span></td>
					<td><span class="td_right">'.$row_print['freight'].'</span></td>';
					$p_id = $row_print['partyname'];
					echo '<td>';
							$sql2="SELECT * FROM `party` WHERE `ID`='$p_id'";
							$result2 = $db->query($sql2) or die("Sql Error :" . $db->error);
							$row2 = mysqli_fetch_array($result2);
								if($row2['ID']==$p_id){
									echo $row2['name'];
								}
					echo'</td>
					<td>'.$row_print['dateofdeparture'].'</td>
					<td>'.$row_print['date_of_print'].'</td>';
					if(preg_match($ptrn_paid,$perm)){
						echo '<td><a href="pakka_view.php?challan_id='.$row_print['ID'].'" >View</a></td>';
					}
				
					echo '</tr>';
				}






}
//-----------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------END Printed Pakka challan--------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------
?>
<script>var allVals=[];
<?php
		$f=$count;
		while($f>0){
			echo"$('#".$f."_freight').change(function(){
				$(this).val(evil($(this).val()));
			});";
			$f--;
		}
	?>
<?php $j=$count;
		if(preg_match($ptrn_update,$perm)){
		while($count>0){
			echo '$("#'.$count.'").click(function(){
				if($(this).is(":checked")){
					$(".'.$count.'_read").attr("readonly",false);
				}
				else{
					$(".'.$count.'_read").attr("readonly",true);
				}
			});';
			$count--;
		}
		}
	?>
	$("#all_select").click(function(){
		$('input:checkbox').not(this).attr('checked', this.checked);
		<?php
			if(preg_match($ptrn_update,$perm)){
			while($j>0){echo '
				if($(this).is(":checked")){
					$(".'.$j.'_read").attr("readonly",false);
				}
				else{
					$(".'.$j.'_read").attr("readonly",true);
				}';
				$j--;
			}
			}
		?>
	});
	$('.j').click(function(){
		allVals=[];
		$('.j :checked').each(function(){
			allVals.push($(this).val());
		});
	});
</script>
