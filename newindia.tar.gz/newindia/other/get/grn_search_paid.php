<?php
	include('../../configure/config.php');
	if(isset($_POST['grn'])){
		$grn=mysqli_real_escape_string($db,$_POST['grn']);
		$sql = "SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`paid_at`,'%d-%m-%Y') as `paid_at` FROM `challan` WHERE `G.R.No`='$grn' AND `paid`=0 AND `is_due`=0";
		$result = $db->query($sql) or die("Sql Error :" . $db->error);
		$total_paid=0;
		$total_freight=0;
		$total_admjustment=0;$i=1;
		$count = mysqli_num_rows($result);
		if($count>0){
		echo '<table>
		<tr>
			<th>#</th>
			<th>Challan No</th>
			<th>Marka</th>
			<th>Nag</th>
			<th>Particular</th>
			<th>weight</th>
			<th>freight</th>
			<th>Adjustment</th>
			<th>Paid Amount</th>
			<th>partyname</th>
			<th>dateofdeparture</th>
			<th>truckno</th>
		</tr>';
		
		while($row = mysqli_fetch_array($result)){
			echo '<tr>
				<td><label><input type="checkbox" id="'.$i.'" name="count[]" value="'.$i.'" >
					<input type="hidden" name="'.$i.'_id_value" value="'.$row['ID'].'">'.$i.'</label></td>
				<td><span class="td_right">'.$row['challanNo'].'</span></td>
				<td>'.$row['marka'].'</td>
				<td><span class="td_right">'.$row['nag'].'</span></td>
				<td>'.$row['particular'].'</td>
				<td><span class="td_right">'.$row['weight'].'</span></td>
				<td><span class="td_right">'.$row['freight'].'<input type="hidden" id="'.$i.'_freight" name="'.$i.'_freight" value="'.$row['freight'].'"></span></td>
				<td><input type="number" class="'.$i.'_read" name="'.$i.'_adjustment" id="'.$i.'_adjustment" value="'.$row['adjustment'].'" readonly></td>';
				$p_id=$row['partyname'];
				$p_sql = "SELECT * FROM `party` WHERE `ID`='$p_id'";
				$p_result = $db->query($p_sql) or die("Sql Error :" . $db->error);
				$p_row = mysqli_fetch_array($p_result);
				echo '<td><span class="td_right" id="'.$i.'_adjustment_td">'.($row['freight']-$row['adjustment']).'</span></td>
				<td>'.$p_row['name'].'</td>
				<td>'.$row['dateofdeparture'].'</td>
				<td>'.$row['truckno'].'</td>
			</tr>';$i++;
		}
		echo'<br><br></table>';
		}
		else{
			echo '<h2>G.R.No is invalide in unpaid challan list</h2>';
		}
	}
?>
<script>
<?php
		$j=$i;
		while($j>0){
			echo '$("#'.$j.'").click(function(){
				if($(this).is(":checked")){
					$(".'.$j.'_read").attr("readonly",false);
				}
				else{
					$(".'.$j.'_read").attr("readonly",true);
				}
			});';
			$j--;
		}
	?>
	<?php
		$m=$i;
		while($m>0){
			echo "
				$('#".$m."_adjustment').change( function(){
					freight = $('#".$m."_freight').val();
					paidamount = $('#".$m."_adjustment').val();
					$('#".$m."_adjustment_td').html((+freight)-(+paidamount));	
				});
			";
			$m--;
		}
	?>
</script>
