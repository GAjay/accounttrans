<?php
	include('../../configure/config.php');
	if(isset($_POST['challanNo'])){
		$challan=mysqli_real_escape_string($db,$_POST['challanNo']);
		$sql = "SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture`, DATE_FORMAT(`paid_at`,'%d-%m-%Y') as `paid_at` FROM `challan` WHERE `challanNo`='$challan' ";
		$result = $db->query($sql) or die("Sql Error :" . $db->error);$count = mysqli_num_rows($result);
		$total_paid=0;
		$total_freight=0;
		$total_admjustment=0;$i=1;
		$total_weight=0;
		$total_nag=0;
		if($count>0){
		echo '<table>
		<tr>
			<th>#</th>
			<th>G.R.No</th>
			<th>Marka</th>
			<th>Nag</th>
			<th>Particular</th>
			<th>weight</th>
			<th>freight</th>
			<th>Adjustment</th>
			<th>Paid Amount</th>
			<th>Paid at</th>
			<th>partyname</th>
			<th>D.O.B.</th>
			<th>truckno</th>
		</tr>';
		
		while($row = mysqli_fetch_array($result)){
			echo '<tr>
				<td><span class="td_right">'.$i.'</span></td>
				<td><span class="td_right">'.$row['G.R.No'].'</span></td>
				<td>'.$row['marka'].'</td>
				<td>'.$row['nag'].'</td>
				<td>'.$row['particular'].'</td>
				<td><span class="td_right">'.$row['weight'].'</span></td>
				<td><span class="td_right">'.$row['freight'].'</span></td>
				<td><span class="td_right">';
				if($row['adjustment']==0){echo 'No adjustment';}else{echo $row['adjustment'];}$paid=$row['freight']-$row['adjustment'];if($row['paid']==1){$paid_at=$row['paid_at'];}else{$paid_at='';}
				$p_id=$row['partyname'];
				$p_sql = "SELECT * FROM `party` WHERE `ID`='$p_id'";
				$p_result = $db->query($p_sql) or die("Sql Error :" . $db->error);
				$p_row = mysqli_fetch_array($p_result);
				echo '</span></td>
				<td><span class="td_right">'.$paid.'</span></td>
				<td>'.$paid_at.'</td>
				<td>'.$p_row['name'].'</td>
				<td>'.$row['dateofdeparture'].'</td>
				<td>'.$row['truckno'].'</td>
			</tr>';
			$total_paid=$total_paid+$paid;
			$total_freight=$total_freight+$row['freight'];
			$total_admjustment=$total_admjustment+$row['adjustment'];
			$total_weight=$total_weight+$row['weight'];
			$total_nag=$total_nag+$row['nag'];
			$i++;
		}
		echo'<br><div class="button_left"><label>Total Freight: '.$total_freight.'</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Total Adjustment: '.$total_admjustment.'</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Total Paid: '.$total_paid.'</label></div>
		<div class="button_right"><label>Total Nag: '.$total_nag.'</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Total Weight: '.$total_weight.'</label></div>
		<br></table>';
		}
		else{
			echo '<h2>Challan No is invalide</h2>';
		}
	}
?>
