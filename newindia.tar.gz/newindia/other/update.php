<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$member_id=$_SESSION['ID'];
if($_SERVER['REQUEST_METHOD']=='POST'){
	$check=false;
	$u_name = $_POST['u_name'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$sql = ("UPDATE `users` SET `partyname`='$name',`address`='$address' WHERE `ID`='$member_id'");
	if($_POST['check']==1){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$password = md5($password);
		$check = true;
		if(($username!=$u_name)&&($_POST['password']!='')){
			$sql = ("UPDATE `users` SET `username`='$username', `password`='$password', `partyname`='$name',`address`='$address' WHERE `ID`='$member_id'");
		}
		else if(($username!=$u_name)&&($_POST['password']=='')){
			$sql = ("UPDATE `users` SET `username`='$username', `partyname`='$name',`address`='$address' WHERE `ID`='$member_id'");
		}
		else if(($username==$u_name)&&($_POST['password']!='')){
			$sql = ("UPDATE `users` SET `password`='$password', `partyname`='$name',`address`='$address' WHERE `ID`='$member_id'");
		}
		$_SESSION['login_user'] = $username;
	}
	$result = $db->query($sql) or die("Sql Error :" . $db->error);
	$_SESSION['u_name']=$name;
	if($result&&!$check){
		echo '<script>parent.window.location="../welcome.php?update=true";</script>';
    }
	else if($result&&$check){
		echo '<script>parent.window.location="../configure/logout.php?updated=updated";</script>';
    }
}
?>